﻿using System.Windows;
using SchoolMangement.ViewModel;

namespace SchoolMangement
{
   
    public partial class MainWindow : Window
    {
        public MainWindow(TopBarViewModel topBarVM)
        {
            InitializeComponent();
            DataContext = topBarVM;
        }


    }
}