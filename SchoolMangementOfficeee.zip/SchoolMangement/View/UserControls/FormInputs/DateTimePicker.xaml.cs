﻿using System.Windows;

namespace SchoolMangement.View.UserControls.FormInputs
{

    public partial class DateTimePicker 
    {
        public static readonly DependencyProperty DateValueProperty =
          DependencyProperty.Register(
            "DateValue",
            typeof(DateTime), // 1. Must be DateTime
            typeof(DateTimePicker),
            new FrameworkPropertyMetadata(
                DateTime.Now, // 2. Must be a DateTime object, not string.Empty
                FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public DateTime DateValue
        {
            get => (DateTime)GetValue(DateValueProperty); // 3. Cast to DateTime
            set => SetValue(DateValueProperty, value);
        }

        public DateTimePicker() => InitializeComponent();
    }
}
