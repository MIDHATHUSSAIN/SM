﻿using Newtonsoft.Json;
using SchoolMangement.Classes;
using SchoolMangement.Connection;
using SchoolMangement.Helper;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
namespace SchoolMangement.ViewModel
{
    public class FormInputViewModel: INotifyPropertyChanged
    {

        private readonly TopBarViewModel _topBarViewModel;

        private string _topHeading = "Sign In";
        public User UserData { get; set; } = new User();

        public string TopHeading
        {
            get => _topHeading;
            set { _topHeading = value; OnPropertyChanged(); }
        }

        public bool IsSignUpMode => TopHeading == "Sign Up";
        public bool IsSignInMode => TopHeading == "Sign In";
        public event PropertyChangedEventHandler? PropertyChanged;
        public ICommand SignUp { get;}
        public ICommand SignIn { get; }
        //public ICommand SignOut { get; }
        public ICommand SignUpText {  get; }
        public ICommand SignInText { get; }
        public string ConformPassword { get; set; }
       
        public FormInputViewModel(TopBarViewModel topBarViewModel)
        {
            _topBarViewModel = topBarViewModel;
            SignUp = new RelayCommand(MovingToSignUp);
            SignIn = new RelayCommand(MovingToSignIn);
            SignUpText = new RelayCommand(ChangingSignUpText);
            SignInText = new RelayCommand(ChangingSignInText);
            //SignOut = new RelayCommand(MovingToSignOut);
        }
        public void ChangingSignUpText()
        {
            TopHeading = "Sign Up";
            OnPropertyChanged(nameof(IsSignUpMode));
            OnPropertyChanged(nameof(IsSignInMode));
        }

        public void ChangingSignInText()
        {
            TopHeading = "Sign In";
            OnPropertyChanged(nameof(IsSignUpMode));
            OnPropertyChanged(nameof(IsSignInMode));
        }
        public async void MovingToSignUp()
        {
           
            if (UserData.UserPassword != ConformPassword)
            {
                MessageBox.Show("Password and Confirm Password are not same");
                return;

            }
            else if (UserData.UserEmail == null)
            {
                return;
            }

            string PayLoad = JsonConvert.SerializeObject(UserData);

            var response = await MakingConnectionToServer.SendingData(RequestType.SignUp,UserRole.Guest.ToString(), PayLoad);

            MessageBox.Show(response);

        }

        public async void MovingToSignIn()
        {
            try
            {
                
                if(UserData.UserEmail == null || UserData.UserPassword == null)
                {
                    return;
                }

                string PayLoad = JsonConvert.SerializeObject(UserData);

                var response = await MakingConnectionToServer.SendingData(RequestType.SignIn, UserRole.Guest.ToString(), PayLoad);

                if(response.ToString() == "User Not Found")
                {
                    MessageBox.Show("Invalid Password or Email");
                    return;
                }
                var parts = response.Split(':');

                string role = parts[0];
                string name = parts[1];

                    _topBarViewModel.Role = role;
              
                AppSession.Instance.UserName = name;
                AppSession.Instance.Role = role;
                if(role == UserRole.Admin.ToString() || role == UserRole.Teacher.ToString() || role == UserRole.Student.ToString())
                {
                    MainWindow mainWin = new MainWindow(_topBarViewModel);
                    mainWin.Show();
                    var loginWindow = System.Windows.Application.Current.Windows
                     .OfType<System.Windows.Window>()
                     .FirstOrDefault(w => w.IsActive || w.GetType().Name == "LoginSignUpWindow");
                    loginWindow?.Close();

                }
                else
                {
                    MessageBox.Show("You Can't Sign In");
                    return;
                }
               

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        //public void MovingToSignOut()
        //{
        //    TopHeading = "Sign In";
        //}
        private void OnPropertyChanged([CallerMemberName] string PropertyName = null)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
        }
    }
}
