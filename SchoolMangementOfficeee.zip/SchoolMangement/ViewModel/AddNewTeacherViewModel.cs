﻿using Newtonsoft.Json;
using SchoolMangement.Classes;
using SchoolMangement.Connection;
using SchoolMangement.Helper;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    class AddNewTeacherViewModel
    {
        public ICommand TeacherSaveButton { get; }

        public Teacher TeacherData { get; set; } = new Teacher();

        ObservableCollection<Teacher> teachers;
        public AddNewTeacherViewModel()
        {
            TeacherSaveButton = new RelayCommand(SavingTeacher);
        }

        public async void SavingTeacher()
        {
            string PayLoad = JsonConvert.SerializeObject(TeacherData);
            string response = await MakingConnectionToServer.SendingData(RequestType.AddTeacher, AppSession.Instance.Role, PayLoad);
            System.Windows.MessageBox.Show(response);
        }

        public async void DeletingTeacher()
        {
            string PayLoad = JsonConvert.SerializeObject(TeacherData);
            string response = await MakingConnectionToServer.SendingData(RequestType.DeleteTeacher, AppSession.Instance.Role, PayLoad);
            System.Windows.MessageBox.Show(response);
        }
        public async void RetrievingTeacher()
        {
            var response = await MakingConnectionToServer.SendingData(RequestType.RetrievingTeacher, AppSession.Instance.Role, "TeacherData");
            teachers = JsonConvert.DeserializeObject<ObservableCollection<Teacher>>(response);
        }

    }
}
