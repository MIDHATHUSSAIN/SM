﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolMangement.Classes
{
    public enum UserRole
    {
        Admin,
        Teacher,
        Student,
        Guest
    }
}
