﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolMangement.Classes
{
    public enum RequestType
    {
        SignUp,
        SignIn,
        AddTeacher,
        DeleteTeacher,
        RetrievingTeacher,
        AddStudent,
        DeleteStudent,
        RetrievingStudent,
        AddAnnouncement,
        DeleteAnnouncement,
        ViewAnnouncement,
        AddCourses,
        AddResult,
        AddAttendance,
        ViewAnnouncementT,
        ViewSubjects,
        ViewCourses,
        ViewAnnouncementS
    }
}
