﻿using Cache.Lists;
using ComManager.CommunicationManager.CheckingRequests;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ComManager.CommunicationManager.ApplicatiosConnection
{
    public class MakingConnections
    {
        CheckingRequestType Cr = new CheckingRequestType();
   
        public void Connection()
        {
            int port = 5001;
            TcpListener server = new TcpListener(IPAddress.Any, port);
            server.Start();
            Console.WriteLine($"Server is running on {port}");

            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                Console.WriteLine("Client connected.");

                HandleClient(client);
            }
        }

        public void HandleClient(TcpClient client)
        {
            using (NetworkStream stream = client.GetStream())
            {
                byte[] buffer = new byte[1024];

                try
                {
                    while (true)
                    {
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);

                        // If bytesRead is 0, the client has initiated a disconnect
                        if (bytesRead == 0)
                        {
                            CacheData.BeforeClosingLogic();
                            break;
                        }

                        string requestData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        string response = Cr.ProcessRequest(requestData);

                        byte[] responseBuffer = Encoding.UTF8.GetBytes(response);
                        stream.Write(responseBuffer, 0, responseBuffer.Length);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Connection lost unexpectedly: {ex.Message}");
                    CacheData.BeforeClosingLogic();
                }
                //finally
                //{
                //    client.Close();
                //    AfterClosingLogic();
                //}
            }
        }

        //private void BeforeClosingLogic()
        //{
        //    Console.WriteLine("Running abc function BEFORE closing...");
        //    Sd.SaveData("students.xml", MyCache.Students);

        //    // Save Users
        //    Sd.SaveData("users.xml", MyCache.Users);

        //    // Save Teachers
        //    Sd.SaveData("teachers.xml", MyCache.Teachers);

        //    Console.WriteLine("All data saved successfully.");
        //}
        //private void AfterClosingLogic()
        //{
        //    Console.WriteLine("Running abc function AFTER closing...");
        //    // Your post-close logic here
        //}
    }
}
