﻿namespace Uitilies.Types
{
    public enum UserRole
    {
        Admin,
        Teacher,
        Student,
        Guest

    }


}
