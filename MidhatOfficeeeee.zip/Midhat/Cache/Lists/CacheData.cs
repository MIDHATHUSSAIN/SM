﻿using Cache.FilesPath;
using Repo.Repos;
using System.Collections.ObjectModel;
using Uitilies.SerilizationAndDeserilization;

namespace Cache.Lists
{
    public class CacheData
    {
        public static ObservableCollection<Student> Students { get; set; } = new();
        public static ObservableCollection<User> Users { get; set; } = new();
        public static ObservableCollection<Teacher> Teachers { get; set; } = new();
        public static ObservableCollection<Announcement> Announcemts { get; set; } = new();

        public static void LoadingInitialData()
        {
            Students = SerilizingAndDeserilizing.LoadData<Student>(Constants.StudentFilePath, "Students");
            Teachers = SerilizingAndDeserilizing.LoadData<Teacher>(Constants.TeacherFilePath, "Teachers");
            Users = SerilizingAndDeserilizing.LoadData<User>(Constants.UserFilePath, "Users");
            Announcemts = SerilizingAndDeserilizing.LoadData<Announcement>(Constants.AnnouncementFilePath, "Announcements");
        }

        public static void BeforeClosingLogic()
        {
            SerilizingAndDeserilizing.SaveData(Constants.StudentFilePath,Students,"Students");
            SerilizingAndDeserilizing.SaveData(Constants.UserFilePath,Users, "Users");
            SerilizingAndDeserilizing.SaveData(Constants.TeacherFilePath,Teachers, "Teachers");

            Console.WriteLine("All data saved successfully.");
        }
    }


}
