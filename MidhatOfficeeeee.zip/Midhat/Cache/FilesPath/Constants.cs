﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cache.FilesPath
{
    public class Constants
    {
        public static string StudentFilePath = @"D:\Downloads\todayyyy-main\todayyyy-main\Midhat\Midhat\Uitilies\Files\StudentsData.xml";
        public static string TeacherFilePath = @"D:\Downloads\todayyyy-main\todayyyy-main\Midhat\Midhat\Uitilies\Files\TeachersData.xml";
        public static string UserFilePath = @"D:\Downloads\todayyyy-main\todayyyy-main\Midhat\Midhat\Uitilies\Files\UsersData.xml";
        public static string AnnouncementFilePath = @"D:\Downloads\todayyyy-main\todayyyy-main\Midhat\Midhat\Uitilies\Files\AnnouncementData.xml";
    }
}
