﻿using Cache.Lists;
using Repo.Repos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.HandleData.Logics
{
    public class TeacherLogic
    {
      
        public string AddTeacher(Teacher TeacherData)
        {
            var teacher = CacheData.Teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
            if (teacher != null)
            {
                Console.WriteLine("Teacher with this email already exists.");
                return "Teacher with this email already exists.";
            }

            CacheData.Teachers.Add(TeacherData);

            return "Teacher has been Saved";

        }

        public string DeletingTeacher(Teacher TeacherData)
        {
            var teacher = CacheData.Teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
            if (teacher != null)
            {
                CacheData.Teachers.Remove(teacher);
                Console.WriteLine("Teacher Deleted Successfully");

            }
            return "Teacher Deleted Successfully";

        }
        public ObservableCollection<Teacher> FethcingTeacher()
        {
            return CacheData.Teachers;
        }
    }
}
