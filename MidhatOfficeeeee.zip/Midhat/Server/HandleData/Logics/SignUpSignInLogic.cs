﻿using Cache.Lists;
using Repo.Repos;
using Uitilies.Types;
using BC = BCrypt.Net.BCrypt;
namespace Server.HandleData.Logics
{
    public class SignUpSignInLogic
    {
     
        public string SigningUp(User UserData)
        {
            try
            {
                if (CacheData.Teachers != null)
                {
                    var Teacher = CacheData.Teachers.Where(x => x.TeacherEmail == UserData.UserEmail);
                    if (Teacher.Any())
                    {
                        var user = CacheData.Users.Where(x => x.UserEmail == UserData.UserEmail);
                        if (user.Any())
                        {
                            Console.WriteLine("This email is already used,Kidnly Contact Admin");
                            return "This email is already used,Kidnly Contact Admin";
                        }
                        else
                        {
                            string passwordToSave = BC.HashPassword(UserData.UserPassword);
                            UserData.UserPassword = passwordToSave;
                            UserData.UserName = Teacher.FirstOrDefault().TeacherName;
                            UserData.Role = "Teacher";
                            CacheData.Users.Add(UserData);
                            Console.Write("You Can Sign In Now");
                            return "You Can Sign In Now";
                        }
                    }
                    else
                    {
                        if (CacheData.Students != null)
                        {
                            var student = CacheData.Students.Where(x => x.StudentEmail == UserData.UserEmail).ToList();
                            if (student.Any())
                            {
                                var user = CacheData.Users.Where(x => x.UserEmail == UserData.UserEmail);
                                if (user.Any())
                                {
                                    Console.WriteLine("This email is already used,Kidnly Contact Admin");
                                    return "This email is already used,Kidnly Contact Admin";
                                }
                                else
                                {
                                    string passwordToSave = BC.HashPassword(UserData.UserPassword);
                                    UserData.UserPassword = passwordToSave;
                                    UserData.UserName = student[0].StudentName;
                                    UserData.Role = "Student";
                                    CacheData.Users.Add(UserData);
                                    Console.WriteLine("You Can Sign In Now");
                                    return "You Can Sign In Now";
                                }
                            }


                        }

                    }

                }
                return "You Can't Sing Up ,Kidnly Contact Admin";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return "Something Went Wrong";
            }


        }

        public string SigningIn(User UserData)
        {
            try
            {
                var user = CacheData.Users.Where(x => x.UserEmail == UserData.UserEmail).FirstOrDefault();
                if (user != null)
                {

                    bool IsValidPassword = BC.Verify(UserData.UserPassword, user.UserPassword);
                    if ((IsValidPassword))
                    {
                        if (user.Role == UserRole.Admin.ToString())
                        {
                            return $"{user.Role}:{user.UserName}";
                        }
                        else if (user.Role == UserRole.Teacher.ToString())
                        {
                            return $"{user.Role}:{user.UserName}";
                        }
                        else
                        {
                            return $"{user.Role}:{user.UserName}";
                        }
                    }

                }
                return "User Not Found";
            }
                catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }



        }
    }
}
